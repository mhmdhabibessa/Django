from django.db import models
    
class TVshown(models.Model):
    title = models.CharField(max_length=255)
    network = models.CharField(max_length=255)
    discripton =models.CharField(max_length=255)
    relaied_time= models.DateField(auto_now_add=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

