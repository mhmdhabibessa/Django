from django.apps import AppConfig


class StartMyAppConfig(AppConfig):
    name = 'start_my_app'
