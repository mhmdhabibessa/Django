from django.apps import AppConfig


class FavappConfig(AppConfig):
    name = 'Favapp'
