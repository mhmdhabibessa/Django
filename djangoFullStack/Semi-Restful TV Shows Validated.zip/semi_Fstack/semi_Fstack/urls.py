from django.urls import path, include       
urlpatterns = [
    path('', include('semi_app_pro.urls')),
]